#!/bin/bash
#
#################################################################################
# Script Name:  run_redshift_audit.sh
#
# Author:       Kawish Siddiqui, Po Hong
# Purpose:      Run Redshift Audit SQL scripts
#
# Revision History:
#                                  Initial Version (1.0)
#
#################################################################################
#
# Hardcode variables
export RSENDPOINT="<Redshift_EndPoint_Including_PortNumber>"
# example of RSENDPOINT: my-redshift-cluster.xxxxxxxxxx.us-west-2.redshift.amazonaws.com:5439

export DBNAME="<Redshift_DatabaseName>"
export DBUSER="<Redshit_UserName>"
export PGPASSWORD="<Redshift_Password>"

export DBHOST=$(echo ${RSENDPOINT} | cut -d":" -f1)
export DBPORT=$(echo ${RSENDPOINT} | cut -d":" -f2)
export CLUSTERID=$(echo ${RSENDPOINT} | cut -d"." -f1)
export WORKDIR=$(pwd)
export psql="psql -d $DBNAME -h $DBHOST -p $DBPORT -U $DBUSER "

STIME=`date +%s`

if [ ! -d ${WORKDIR}/logs ]; then
   mkdir -p ${WORKDIR}/logs
fi

for i in $(ls *.sql)
do
  ${psql} -ef  $i > ./logs/${i%.sql}.log 2>&1 
done 


ETIME=`date +%s`
RT=`expr $ETIME - $STIME`
echo "End job at `date`...."
echo "The total time taken is $RT seconds."

exit

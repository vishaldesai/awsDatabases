/**********************************************************************************************
Purpose: The hourly overall queue metrics on the leader node. 

Columns:
day_hour:    Day hour range
queue:	Queue number=service_class-5
node: 	Leader only = -1
count_commit_xid:	Total # of commits
wlm_queue_time_sec: Total queue time in seconds
exec_only_time_sec: Total execution time in seconds 
commit_time_sec: Total commit time in seconds 
commit_queue_time_sec: Total commit queue time in seconds 

History:
2017-06-28 created by pohong
**********************************************************************************************/
 
select 
date_trunc('hour',b.starttime) as day_hour, (d.service_class-5) As queue, c.node, count(distinct c.xid) as count_commit_xid, 
SUM(datediff('microsec', d.queue_start_time, d.queue_end_time ))/(1000*1000) as wlm_queue_time_sec, 
SUM(datediff('microsec', b.starttime, b.endtime))/(1000*1000) as exec_only_time_sec, 
SUM(datediff('microsec', c.startwork, c.endtime))/(1000*1000) commit_time_sec, 
SUM(datediff('microsec', DECODE(c.startqueue,'2000-01-01 00:00:00',c.startwork,c.startqueue), c.startwork))/(1000*1000) commit_queue_time_sec 
from stl_query b , 
        stl_commit_stats c, 
         stl_wlm_query d 
where b.xid = c.xid and b.query = d.query and c.xid > 0 
and d.service_class > 5   
and date_trunc('day',b.starttime) >= dateadd(day, -1, current_Date)
and c.node=-1
group by date_trunc('hour',b.starttime), d.service_class,c.node 
having ( SUM(datediff('microsec', d.queue_start_time, d.queue_end_time ))  > 0  OR 
SUM(datediff('microsec', DECODE(c.startqueue,'2000-01-01 00:00:00',c.startwork,c.startqueue), c.startwork))  > 0 )
order by date_trunc('hour',b.starttime), d.service_class,c.node 
;
     

/**********************************************************************************************
Purpose: Query showing the total amount of spill for different queues in the last three days

Columns:
Queue:  Custom queue number
Run_Date: Execution date of a query
Total_Query_Count: Total # of queries executed
total_spill_rows: Total # of spilt rows
total_spill_MB:  Total size in MB of spilt rows

History:
2017-08-01  pohong
**********************************************************************************************/

SELECT  (a.service_class-5) As Queue,
      qry.starttime::date AS Run_Date,
       COUNT( DISTINCT smry.query) As Total_Query_Count,
       SUM(smry.ROWS) AS total_spill_rows,
       SUM(smry.bytes)/(1024*1024)  As total_spill_MB
FROM svl_query_summary smry
JOIN stl_query qry ON qry.query = smry.query
JOIN stl_wlm_query a ON a.query = qry.query
WHERE smry.is_diskbased = 't'
  AND qry.starttime::date  >=  dateadd(day, -3, current_Date)
  AND a.service_class > 5
GROUP BY 1,2
ORDER BY 1,2;        


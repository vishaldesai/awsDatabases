/**********************************************************************************************
Purpose: Return commit queue statistics on the lead node from the last two days, 
showing largest queue length and queue time first

Columns:
queue_day_hour:		Queue day hour
queue_time:		Queue time in seconds
commit_time:		Commit time in seconds
queuelen:		               Number of transactions in the queue

Notes:

History:
2015-02-09 ericfe created
2017-07-05 pohong updated
**********************************************************************************************/
select date_trunc('hour', startqueue) as queue_day_hour, MAX(datediff(ms,startqueue,startwork))/1000 as max_queue_time_sec, 
MAX(datediff(ms, startwork, endtime))/1000 as max_commit_time_sec, MAX(queuelen) as max_queue_length
from stl_commit_stats 
where startqueue >=  dateadd(day, -1, current_Date)
and node=-1
group by 1
order by 1;


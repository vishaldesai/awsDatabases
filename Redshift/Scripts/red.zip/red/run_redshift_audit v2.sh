#!/bin/bash

WORKDIR=$(pwd)

STIME=`date +%s`

if [ ! -d ${WORKDIR}/logs ]; then

mkdir -p ${WORKDIR}/logs

fi

echo "Start the job at `date`...."

for i in `ls *.sql`
do


${psql}  -ef  $i > ./logs/${i%.sql}.log 2>&1 

done 


ETIME=`date +%s`
RT=`expr $ETIME - $STIME`
echo "End job at `date`...."
echo "The total time taken is $RT seconds."

exit

# Redshift Admin Scripts
Scripts objective is to help on tuning and troubleshooting.
If you are using psql, you can use ``` psql [option] -f &lt;script.sql&gt;``` to run.

| Script | Purpose |
| ------------- | ------------- |
| commit_stats.sql | Shows information on consumption of cluster resources through COMMIT statements |
| copy_performance.sql | Shows longest running copy for past 7 days |
| query_spill_summary.sql | Query showing the total amount of spill for different queues in the last three days |
| filter_used.sql | Return filter applied to tables on scans. To aid on choosing sortkey |
| missing_table_stats.sql | Query shows EXPLAIN plans which flagged "missing statistics" on the underlying tables |
| perf_alert.sql | Return top occurrences of alerts, join with table scans |
| queuing_queries.sql | Query showing queries which are waiting on a WLM Query Slot |
| table_info.sql | Return Table storage information (size, skew, etc) |
| table_inspector.sql | Table Analysis. Complements table_info.sql |
| top_queries.sql | Return the top 50 most time consuming statements in the last 7 days |
| unscanned_table_summary.sql | Summarizes storage consumed by unscanned tables |
| wlm_apex.sql | Returns overall high water-mark for WLM query queues and time queuing last occurred |
| wlm_apex_hourly.sql | Returns hourly high water-mark for WLM query queues |
| wlm_commit_queue_time_tracking | Returns hourly commit and queue time for different queues |

Run script:

Create a logs directory in the same location as these audit SQL scripts and exectute the following:

nohup ./run_redshift_audit.sh  >run_redshift_audit.log 2>&1 &

All the audit logs will be in the logs directory.  Need to make sure that run_redshift_audit.sh is executable (chmod +x). 



